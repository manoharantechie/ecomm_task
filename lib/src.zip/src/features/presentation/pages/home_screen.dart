import 'package:e_comm/src/core/init/const_value.dart';
import 'package:e_comm/src/core/theme/custom_theme.dart';
import 'package:e_comm/src/features/presentation/widgets/carousel.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomTheme.of(context).primaryColor,
      body: Container(
        height: ConstantValues.height(context),
        width: ConstantValues.width(context),
        color: CustomTheme.of(context).primaryColor,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: ConstantValues.height(context)*0.3,
                width: ConstantValues.width(context),
                child: OffersCarousel(),
              )
            ],
          ),

        ),
      ),
    );
  }
}
