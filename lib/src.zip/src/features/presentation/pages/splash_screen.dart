import 'dart:async';

import 'package:e_comm/src/core/routes/route_path.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  String wel = "";
  String check = "1";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  //  getData();
    onLoad();
  }

  getData() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    wel = preferences.getString("welcomeregu").toString();
    check = preferences.getString("login").toString();
    onLoad();
  }

  onLoad() {
    setState(() {
      if (check == "1") {
        Future.delayed(Duration(seconds: 2), () {
          // This works now because ProfileCubit is provided
          context.pushReplacementNamed(AppRoute.home.name,
              // pathParameters: {"auth": "true"}
          ); // Navigate to HomeScreen
        });
      }
      // else if (wel == null || wel == "null") {
      //   Timer(const Duration(seconds: 5),
      //           () => context.goNamed(AppRoute.onboard.name));
      // } else {
      //   Timer(
      //       const Duration(seconds: 5),
      //           () => context.goNamed(
      //         AppRoute.login.name,
      //       ));
      // }
      // checkDeviceID(deviceData['device_id'].toString());
    });
//   UnderMaintenance(),
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(


    );
  }
}
