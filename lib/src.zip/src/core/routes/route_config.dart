import 'package:e_comm/src/core/routes/route_path.dart';
import 'package:e_comm/src/features/presentation/pages/dash_screen.dart';
import 'package:e_comm/src/features/presentation/pages/home_screen.dart';
import 'package:e_comm/src/features/presentation/pages/splash_screen.dart';
import 'package:go_router/go_router.dart';


class AppRouteConf {
  GoRouter get router => _router;

  late final _router = GoRouter(
    initialLocation: AppRoute.splash.path,
    debugLogDiagnostics: true,
    routes: [
      GoRoute(
        path: AppRoute.splash.path,
        name: AppRoute.splash.name,
        builder: (_, __) => const SplashScreen(),
        routes: [

          GoRoute(
            path: AppRoute.home.path,
            name: AppRoute.home.name,
            builder: (context, state) => HomeScreen(

            ),
          ),
          GoRoute(
            path: AppRoute.dashboard.path,
            name: AppRoute.dashboard.name,
            builder: (_, __) => DashScreen(),
          ),
        ],
      ),
      // GoRoute(
      //   path: AppRoute.market.path,
      //   name: AppRoute.market.name,
      //   builder: (_, __) => MarketPage(),
      // ),

    ],
  );
}
